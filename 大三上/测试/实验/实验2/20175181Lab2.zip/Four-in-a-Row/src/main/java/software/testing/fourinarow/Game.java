package software.testing.fourinarow;

/**
 * Represents the grid that holds the pieces that have been
 * placed into each column.
 */
public class Game {

    /** The maximum number of rows in the game grid */
    public static int MAXIMUM_ROWS = 6;

    /** The maximum number of columns in the game grid */
    public static int MAXIMUM_COLUMNS = 7;

    /** The game grid that holds information about the status of each cell */
    private CellStatus[][] gameGrid;

    public int[] lastSelectedCell = new int[2];
    private boolean redoFlag = false;

    /**
     * Creates a new instance, initialising the board with the
     * Maximum values for columns and rows.
     */
    public Game() {
        gameGrid = new CellStatus[MAXIMUM_COLUMNS][MAXIMUM_ROWS];
    }

    /**
     * Returns the number of cells in a column that have the status
     * GridCellStatus.EMPTY.
     *
     * @param column The column to check. This is 0 indexed, so 0 represents column 1.
     * @return A count of the number of empty cells.
     * @throws FourInARowException if the column value is outside the range
     * 0 to MAXIMUM_COLUMNS.
     */
    public int numberOfEmptyCellsInColumn(int column) throws FourInARowException {

        int emptyCount = 0;

        for(int row = 0; row < MAXIMUM_ROWS; row++) {
            if(getCellStatus(column, row) == CellStatus.EMPTY) {
                emptyCount++;
            }
        }

        return emptyCount;
    }

    /**
     * Gets the GridCellStatus for a cell at the given grid position.
     * @param row The number of the row, with 0 representing the first row.
     * @param column The number of the column, with 0 representing the first column.
     * @return The status value for the grid at the specified position.
     * @throws FourInARowException if the row or column number is out of bounds for the
     * number of rows and columns.
     */
    public CellStatus getCellStatus(int column, int row)
           throws FourInARowException {

        if(row < 0) {
            throw new FourInARowException("Row cannot be negative");
        }

        if(row > MAXIMUM_ROWS - 1) {
            throw new FourInARowException("Row cannot be greater than the number of rows");
        }

        if(column < 0) {
            throw new FourInARowException("Column cannot be negative");
        }

        if(column > MAXIMUM_COLUMNS - 1) {
            throw new FourInARowException("Column cannot be greater than the number of columns");
        }

        return gameGrid[column][row];
    }

    /**
     * Resets the board so that every position contains the value
     * GridCellStatus.EMPTY.
     */
    public void reset() {
        for(int column = 0; column < MAXIMUM_COLUMNS; column++) {
            for(int row = 0; row < MAXIMUM_ROWS; row++) {
                gameGrid[column][row] = CellStatus.EMPTY;
            }
        }

    }

    /**
    * Get the number of empty cells in the gird.
    * Iterate through every column and call numberOfEmptyCellsInColumn function.
    * @return the number of empty cells in the grid
    * @throws FourInARowException if the row or column number is out of bounds for the
    * number of rows and columns.
    */
    public int numOfEmptyCells() throws FourInARowException {
        int num = 0;
        for (int i = 0; i < MAXIMUM_COLUMNS; i++) {
            num += numberOfEmptyCellsInColumn(i);
        }
        return num;
    }

    /**
    * Get the current active player of the game.
    * We use the number of empty cells to decide which player is currently active.
    * If numOfEmptyCells return an even number, Player One is currently active.
    * If numOfEmptyCells return an odd number, Player Two is currently active.
    * @return the player who is currently active
    * @throws FourInARowException if the row or column number is out of bounds for the
    * number of rows and columns.
    */

    public Player getActivePlayer() throws FourInARowException{
        if (numOfEmptyCells() % 2 == 0)
            return Player.ONE;
        else
            return Player.TWO;
    }

    /**
     * Get the current player to take turn and take one empty cell of the column he chose.
     * And we record the column and row we have taken for further use.
     * @param column the column that current player choose
     * @return return ture if there is an empty space in that column
     *         return false if there is no empty space in that column
     * @throws FourInARowException if the row or column number is out of bounds for the
     *         number of rows and columns.
    */
    public boolean takeTurn(int column) throws FourInARowException{
        Player current = getActivePlayer();
        int n = numberOfEmptyCellsInColumn(column);
        if (n == 0){
            return false;
        }else {
            if (current == Player.ONE)
                gameGrid[column][n - 1] = CellStatus.PLAYER_ONE;
            else
                gameGrid[column][n - 1] = CellStatus.PLAYER_TWO;
            lastSelectedCell[0] = column;
            lastSelectedCell[1] = n - 1;
            return true;
        }
    }

    /**
    * reset the game
    * */
    public void resetGame(){
        reset();
        lastSelectedCell = new int[2];
    }

    /**
     * Check if there is a horizontal win
     * @param col the column to check horizontal win
     * @param row the row to check horizontal win
     * @return return true if there is a horizontal win and false if not.
    * */
    public boolean horizontallyWin(int col, int row){
        int counterOfLeft = 0;
        int counterOfRight = 0;
        CellStatus player = gameGrid[col][row];
        int numOfLeft = Math.min(3,col); //number of the left cells that should be check
        int numOfRight = Math.min(3,MAXIMUM_COLUMNS-1-col); //number of the right cells that should be check

        // count the number of cells with the same status in the left
//        boolean leftFlag = true;
        for (int i = col-1; i >= col-numOfLeft; i--) {
            if (player == gameGrid[i][row]){
                counterOfLeft++;
            }else {
//                leftFlag = false;
                break;
            }
        }
        // count the number of cells with the same status in the right
//        boolean rightFlag = true;
        for (int i = col+1; i <= col+numOfRight; i++) {
            if (player == gameGrid[i][row]){
                counterOfRight ++;
            }
            else {
//                rightFlag = false;
                break;
            }
        }
        return counterOfLeft+counterOfRight>=3;
    }

    /**
     * Check if there is a vertical win
     * @param col the column to check vertical win
     * @param row the row to check vertical win
     * @return return true if there is a vertical win and false if not.
     * */
    public boolean verticallyWin(int col, int row){
        int counterOfUp = 0;
        int counterOfDown = 0;
        CellStatus player = gameGrid[col][row];
        int numOfDown = Math.min(3,row); //number of the down cells that should be check
        int numOfUp = Math.min(3,MAXIMUM_ROWS-1-row); //number of the up cells that should be check

        // count the number of cells with the same status downward
//        boolean downFlag = true;
        for (int i = row-1; i >= row-numOfDown; i--) {
            if (player == gameGrid[col][i]){
                counterOfDown ++;
            }else {
//                downFlag = false;
                break;
            }
        }

        // count the number of cells with the same status upward
//        boolean upFlag = true;
        for (int i = row + 1; i <= row+numOfUp; i++) {
            if (player == gameGrid[col][i]){
                counterOfUp ++;
            }else {
//                upFlag = false;
                break;
            }
        }
        return counterOfDown + counterOfUp >= 3;
    }

    /**
     * Check if there is a diagonal win
     * @param col the column to check diagonal win
     * @param row the row to check diagonal win
     * @return return true if there is a diagonal win and false if not.
     * */
    public boolean diagonallyWin(int col, int row){
        int counterOfUpleft = 0;
        int counterOfUpright = 0;
        int counterOfDownleft = 0;
        int counterOfDownright = 0;
        CellStatus player = gameGrid[col][row];
        int numOfUpleft = Math.min(Math.min(row,3),Math.min(col,3)); //number of the up left cells that should be check
        int numOfUpright = Math.min(Math.min(row,3),Math.min(MAXIMUM_COLUMNS-1-col,3)); //number of the up right cells that should be check
        int numOfDownleft = Math.min(Math.min(col,3),Math.min(MAXIMUM_ROWS-1-row,3)); //number of the down left cells that should be check
        int numOfDownright = Math.min(Math.min(MAXIMUM_ROWS-1-row,3),Math.min(MAXIMUM_COLUMNS-1-col,3)); //number of the down right cells that should be check

        // count the number of cells with the same status upleft
        for (int i = row-1,j=col-1; j >= col-numOfUpleft; i--,j--) {
            if (player==gameGrid[j][i]){
                counterOfUpleft++;
            }else {
                break;
            }
        }

        // count the number of cells with the same status up right
        for (int i = row-1,j=col+1; j <= col+numOfUpright; i--,j++) {
            if (player==gameGrid[j][i]){
                counterOfUpright++;
            }else {
                break;
            }
        }

        // count the number of cells with the same status down left
        for (int i = row+1,j=col-1; j >= col-numOfDownleft ; i++,j--) {
            if (player==gameGrid[j][i]){
                counterOfDownleft++;
            }else {
                break;
            }
        }

        // count the number of cells with the same status down right
        for (int i = row+1,j=col+1; j <= col+numOfDownright ; i++,j++) {
            if (player==gameGrid[j][i]){
                counterOfDownright++;
            }else {
                break;
            }
        }

        return counterOfUpleft+counterOfDownright>=3 || counterOfUpright+counterOfDownleft>=3;
    }

    /**
     * Check if there is a win after player has taken a turn.
     * @return turn if there is a win and false if not.
    * */
    public boolean hasWon(){
        return horizontallyWin(lastSelectedCell[0],lastSelectedCell[1]) || verticallyWin(lastSelectedCell[0],lastSelectedCell[1]) || diagonallyWin(lastSelectedCell[0],lastSelectedCell[1]);
    }

    /**
     * allow player to undo the operation
     * @return true if undo is successful
    * */
    public boolean undo(){
        gameGrid[lastSelectedCell[0]][lastSelectedCell[1]] = CellStatus.EMPTY;
        redoFlag = true; //after a undo, we can redo.
        return true;
    }

    /**
     * allow player to redo the operation after undo is done
     * @return true if redo is successful
    * */
    public boolean redo() throws FourInARowException {
        if (redoFlag){
            Player p = getActivePlayer();
            if (p == Player.ONE)
                gameGrid[lastSelectedCell[0]][lastSelectedCell[1]] = CellStatus.PLAYER_ONE;

            else
                gameGrid[lastSelectedCell[0]][lastSelectedCell[1]] = CellStatus.PLAYER_TWO;
            redoFlag = false;
            return true;
        }else {
            return false;
        }


    }
}

