package software.testing.fourinarow;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class GameExtraTest {

    Game game = null;

    @BeforeEach
    public void init(){
        game = new Game();
        game.reset();
    }

    @Test
    void testNumOfEmptyCells() throws Exception{
        assertEquals(42,game.numOfEmptyCells());
    }

    @Test
    public void testGetActivePlayer() throws FourInARowException{
        assertEquals(Player.ONE, game.getActivePlayer());
    }

    @Test
    void testTakeTurn() throws Exception{
        game.takeTurn(0);
        assertEquals(Player.TWO, game.getActivePlayer());
        assertEquals(41,game.numOfEmptyCells());
        assertEquals(5,game.numberOfEmptyCellsInColumn(0));
        game.takeTurn(0);
        assertEquals(40,game.numOfEmptyCells());
    }
    @Test
    void testTakeTurnInColumnOne() throws Exception{
        assertTrue(game.takeTurn(1));
        assertEquals(Player.TWO, game.getActivePlayer());
        assertEquals(41,game.numOfEmptyCells());
        assertEquals(5,game.numberOfEmptyCellsInColumn(1));
        game.takeTurn(1);
        assertEquals(40,game.numOfEmptyCells());

        assertEquals(Player.ONE,game.getActivePlayer());
    }

    @Test
    void testTakeTurnFull() throws Exception{
        assertTrue(game.takeTurn(1));
        assertTrue(game.takeTurn(1));
        assertTrue(game.takeTurn(1));
        assertTrue(game.takeTurn(1));
        assertTrue(game.takeTurn(1));
        assertTrue(game.takeTurn(1));
        assertFalse(game.takeTurn(1));
    }

    @Test
    void testHorizontallyWin() throws Exception{
        game.takeTurn(1);
        game.takeTurn(1);
        game.takeTurn(2);
        game.takeTurn(2);
        game.takeTurn(3);
        game.takeTurn(3);
        game.takeTurn(4);
        assertTrue(game.horizontallyWin(game.lastSelectedCell[0],game.lastSelectedCell[1]));
    }

    @Test
    void testHorizontallyWinLeft() throws FourInARowException{
        game.takeTurn(4);
        game.takeTurn(4);
        game.takeTurn(3);
        game.takeTurn(3);
        game.takeTurn(2);
        game.takeTurn(2);
        game.takeTurn(1);
        assertTrue(game.horizontallyWin(game.lastSelectedCell[0],game.lastSelectedCell[1]));
        assertTrue(game.hasWon());

    }

    @Test
    void testVerticallyWin() throws Exception{
        game.takeTurn(1);
        game.takeTurn(2);
        game.takeTurn(1);
        game.takeTurn(2);
        assertFalse(game.verticallyWin(game.lastSelectedCell[0],game.lastSelectedCell[1]));
        game.takeTurn(1);
        assertFalse(game.verticallyWin(1,game.lastSelectedCell[1]-1));
        game.takeTurn(2);
        game.takeTurn(1);
        assertTrue(game.verticallyWin(game.lastSelectedCell[0],game.lastSelectedCell[1]));
        assertTrue(game.hasWon());
    }

    @Test
    void testDiagonallyWin() throws Exception{
        game.takeTurn(1);
        game.takeTurn(2);
        game.takeTurn(2);
        game.takeTurn(3);
        assertFalse(game.diagonallyWin(game.lastSelectedCell[0],game.lastSelectedCell[1]));
        game.takeTurn(3);
        game.takeTurn(4);
        game.takeTurn(3);
        game.takeTurn(4);
        game.takeTurn(4);
        assertFalse(game.diagonallyWin(1,5));
        assertFalse(game.diagonallyWin(2,4));
        assertFalse(game.diagonallyWin(2,5));
        assertFalse(game.diagonallyWin(3,3));
        assertFalse(game.diagonallyWin(3,4));
        assertFalse(game.diagonallyWin(3,game.lastSelectedCell[1]));
        assertFalse(game.diagonallyWin(3,game.lastSelectedCell[1]+1));
        assertFalse(game.diagonallyWin(4,game.lastSelectedCell[1]));
        assertFalse(game.diagonallyWin(4,game.lastSelectedCell[1]+1));
        game.takeTurn(5);
        game.takeTurn(4);
        assertTrue(game.diagonallyWin(game.lastSelectedCell[0],game.lastSelectedCell[1]));
//        assertTrue(game.diagonallyWin(1,5));
    }

    @Test
    void testDiagonallyWinAnotherWay() throws FourInARowException{
        game.takeTurn(5);
        game.takeTurn(4);
        game.takeTurn(4);
        game.takeTurn(3);
        game.takeTurn(3);
        game.takeTurn(2);
        game.takeTurn(3);
        assertFalse(game.diagonallyWin(4,4));
        game.takeTurn(2);
        game.takeTurn(2);
        game.takeTurn(6);
        game.takeTurn(2);
        assertTrue(game.diagonallyWin(5,5));
        assertTrue(game.diagonallyWin(game.lastSelectedCell[0],game.lastSelectedCell[1]));
        assertTrue(game.hasWon());
    }

    @Test
    void testDiagonallyWinTheOtherWay() throws FourInARowException {
        game.takeTurn(1);
        game.takeTurn(2);
        game.takeTurn(2);
        game.takeTurn(3);
        game.takeTurn(4);
        game.takeTurn(4);
        game.takeTurn(4);
        game.takeTurn(3);
        game.takeTurn(4);
        game.takeTurn(1);
        game.takeTurn(3);
        assertTrue(game.diagonallyWin(1,5));
        assertTrue(game.diagonallyWin(game.lastSelectedCell[0],game.lastSelectedCell[1]));
    }

    @Test
    void testHasWon() throws Exception{
        game.takeTurn(1);
        assertFalse(game.hasWon());
        game.takeTurn(2);
        game.takeTurn(1);
        game.takeTurn(2);
        game.takeTurn(1);
        game.takeTurn(2);
        assertFalse(game.hasWon());
        game.takeTurn(1);
        assertTrue(game.hasWon());
    }

    @Test
    void testUndo() throws FourInARowException{
        game.takeTurn(1);
        game.undo();
        assertEquals(CellStatus.EMPTY,game.getCellStatus(game.lastSelectedCell[0],game.lastSelectedCell[1]));
    }

    @Test
    void testRedoPlayerOne() throws FourInARowException{
        game.takeTurn(1);
        game.undo();
        assertTrue(game.redo());
        assertEquals(CellStatus.PLAYER_ONE,game.getCellStatus(game.lastSelectedCell[0],game.lastSelectedCell[1]));
        assertFalse(game.redo());
    }
    @Test
    void testRedoPlayerTwo() throws FourInARowException{
        game.takeTurn(1);
        game.takeTurn(1);
        game.undo();
        assertTrue(game.redo());
        assertEquals(CellStatus.PLAYER_TWO,game.getCellStatus(game.lastSelectedCell[0],game.lastSelectedCell[1]));
        assertFalse(game.redo());
    }

    @Test
    void testResetGame() throws FourInARowException{
        game.takeTurn(1);
        game.takeTurn(2);
        game.takeTurn(3);
        assertNotEquals(42,game.numOfEmptyCells());
        assertEquals(Player.TWO,game.getActivePlayer());
        game.resetGame();
        assertEquals(Player.ONE,game.getActivePlayer());
        assertEquals(0,game.lastSelectedCell[0]);
        assertEquals(0,game.lastSelectedCell[1]);
        assertEquals(42,game.numOfEmptyCells());
    }
}